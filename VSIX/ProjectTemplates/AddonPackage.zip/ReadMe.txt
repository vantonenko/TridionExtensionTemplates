This project template is capable to create an addon package containing multiple extensions.

* In order to use that please add extension projects into your solution using the appropriate project templates
* Then add project references to those extension projects from the current project
* Build the current project
* Now you have the combined zip package generated (added alongside with this readme file)
